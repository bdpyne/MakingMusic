// block statement

public class BlockStmt extends Stmt {

}