// abstract base class for statement ASTs
// this is a base class to simply distinguish
// stmt ASTs from expression ASTs

public abstract class Stmt extends AST {

};
